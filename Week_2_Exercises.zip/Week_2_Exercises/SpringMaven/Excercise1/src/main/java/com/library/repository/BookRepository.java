package com.library.repository;

public class BookRepository {
	public void repositoryTask() {
		System.out.println("Performing repository task...");
	}
}
