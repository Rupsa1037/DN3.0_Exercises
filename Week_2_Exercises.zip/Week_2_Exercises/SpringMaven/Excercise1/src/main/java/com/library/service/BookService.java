package com.library.service;

public class BookService {
	public void bookService() {
		System.out.println("Book servicing...");
	}
}
