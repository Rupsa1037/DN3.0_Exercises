public class PdfDocument implements Document
{
    public void open()
    {
        System.out.println("Opening the Pdf Document");
    }
     public void manage()
    {
        System.out.println("Managing the Pdf Document");
    }
     public void save()
    {
        System.out.println("Saving the Pdf Document");
    }
}