public class ExcelDocument implements Document
{
    public void open()
    {
        System.out.println("Opening the Excel Document");
    }
     public void manage()
    {
        System.out.println("Managing the Excel Document");
    }
     public void save()
    {
        System.out.println("Saving the Excel Document");
    }
}