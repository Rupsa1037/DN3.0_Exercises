public class WordDocument implements Document
{
    public void open()
    {
        System.out.println("Opening the Word Document");
    }
     public void manage()
    {
        System.out.println("Managing the Word Document");
    }
     public void save()
    {
        System.out.println("Saving the Word Document");
    }
}