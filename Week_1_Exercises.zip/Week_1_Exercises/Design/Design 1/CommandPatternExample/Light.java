public class Light 
{
    public void lighton() 
    {
        System.out.println("The light is on");
    }
    public void lightoff() 
    {
        System.out.println("The light is off");
    }
}