public class Stripe
{
    public void p2(double amt)
    {
        System.out.println("Payment is processing "+amt+" by Stripe");
    }
}