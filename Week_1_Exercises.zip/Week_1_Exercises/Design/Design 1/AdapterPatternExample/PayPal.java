public class PayPal
{
    public void p1(double amt)
    {
        System.out.println("Payment is processing "+amt+" by Paypal");
    }
}